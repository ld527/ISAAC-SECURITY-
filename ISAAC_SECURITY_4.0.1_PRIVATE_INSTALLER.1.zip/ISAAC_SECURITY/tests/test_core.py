import sys, unittest, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from core.scoring import assess_headers
from modules import files
class CoreTests(unittest.TestCase):
 def test_header_score_excludes_unchecked_concept(self):
  result=assess_headers({"security_headers":{"strict-transport-security":"max-age=31536000"}})
  self.assertEqual(result["score"],20)
  self.assertEqual(len(result["findings"]),6)
 def test_file_hash_analysis(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/"sample.txt"; p.write_text("hello")
   r=files.analyze_file(p)
   self.assertEqual(len(r["sha256"]),64)
   self.assertFalse(r["modified_original"])
if __name__=="__main__": unittest.main()
