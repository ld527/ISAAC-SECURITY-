import os, platform

def local_privacy_snapshot():
    return {
        "platform": platform.system(),
        "environment_keys_visible": sorted([k for k in os.environ if any(x in k.lower() for x in ("proxy", "http", "https"))]),
        "note": "This reports a few local environment indicators; it does not inspect private app data."
    }
