import socket, ssl, datetime

def inspect(host, port=443):
    host = host.strip()
    ctx = ssl.create_default_context()
    with socket.create_connection((host, int(port)), timeout=8) as sock:
        with ctx.wrap_socket(sock, server_hostname=host) as s:
            cert = s.getpeercert()
            not_after = cert.get("notAfter")
            expiry = datetime.datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=datetime.timezone.utc) if not_after else None
            days_left = (expiry - datetime.datetime.now(datetime.timezone.utc)).days if expiry else None
            return {
                "host": host, "port": int(port), "tls_version": s.version(),
                "cipher": s.cipher(), "certificate_subject": cert.get("subject"),
                "certificate_issuer": cert.get("issuer"),
                "not_after": not_after, "days_until_expiry": days_left, "expiry_warning": bool(days_left is not None and days_left <= 30),
                "hostname_verification": True
            }
