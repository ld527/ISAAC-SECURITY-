def explain_baseline():
    return {
        "checks": [
            "Keep operating system and applications updated.",
            "Enable MFA on important accounts.",
            "Use unique passwords with a password manager.",
            "Remove unused services and exposed admin panels.",
            "Back up important data and test restoration.",
            "Review HTTPS, security headers, and TLS configuration."
        ],
        "note": "This is a hardening checklist, not an exploit test."
    }
