def account_hardening():
    return {
        "checklist": [
            "Use a unique password for every account.",
            "Enable passkeys or authenticator-based MFA.",
            "Review active sessions and sign out unknown devices.",
            "Check recovery email and phone settings.",
            "Remove unknown connected apps and OAuth grants.",
            "Enable login alerts where available."
        ],
        "scope": "Guidance only. This tool does not log in to Gmail, Facebook, or other services."
    }
