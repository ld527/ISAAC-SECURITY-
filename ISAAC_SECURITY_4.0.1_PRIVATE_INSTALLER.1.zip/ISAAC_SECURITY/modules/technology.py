import urllib.request, urllib.error
SIGS={"WordPress":[b"wp-content",b"wp-includes"],"Shopify":[b"cdn.shopify.com"],"Next.js":[b"__NEXT_DATA__"],"Drupal":[b"Drupal.settings"],"Joomla":[b"/media/system/js/"],"React":[b"reactroot",b"__react"],"Cloudflare":[b"cf-ray"],"Vite":[b"/@vite/client"]}
def detect(url,timeout=10):
    if not url.startswith(("http://","https://")): url="https://"+url
    req=urllib.request.Request(url,headers={"User-Agent":"ISAAC-SECURITY/4.0"})
    try: r=urllib.request.urlopen(req,timeout=timeout)
    except urllib.error.HTTPError as e: r=e
    with r:
        body=r.read(500000).lower(); headers={k.lower():v for k,v in r.headers.items()}; status=r.status
    found=[]
    for name,sigs in SIGS.items():
        hits=sum(1 for s in sigs if s.lower() in body or s.lower().decode(errors="ignore") in str(headers).lower())
        if hits: found.append({"technology":name,"confidence":min(95,55+hits*20),"evidence":"public response body/header signature"})
    for header,name in (("server","Web server"),("x-powered-by","Runtime/framework hint"),("via","Proxy/CDN hint")):
        if headers.get(header): found.append({"technology":name,"value":headers[header],"confidence":85,"evidence":header+" response header"})
    return {"url":url,"status":status,"technologies_detected":found,"note":"Fingerprint matches are heuristic indicators, not proof; hidden technologies cannot be inferred."}
