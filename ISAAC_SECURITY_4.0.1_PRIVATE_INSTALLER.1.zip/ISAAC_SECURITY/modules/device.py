import platform, os, shutil

def info():
    return {
        "system": platform.system(), "release": platform.release(),
        "machine": platform.machine(), "python": platform.python_version(),
        "cpu_count": os.cpu_count(), "disk_free_bytes": shutil.disk_usage(".").free
    }
