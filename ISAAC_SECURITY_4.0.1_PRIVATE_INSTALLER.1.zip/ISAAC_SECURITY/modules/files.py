from pathlib import Path
import os

def _resolve(path):
    raw = os.path.expandvars(os.path.expanduser(str(path).strip()))
    if not raw:
        raise ValueError("A folder or file path is required.")
    return Path(raw).resolve()

def inventory(folder):
    p = _resolve(folder)
    if not p.exists():
        raise FileNotFoundError(f"Path does not exist: {p}")
    if not p.is_dir():
        raise NotADirectoryError(f"Not a directory: {p}")
    rows = []
    errors = []
    try:
        entries = sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
    except PermissionError as exc:
        raise PermissionError(f"Permission denied: {p}") from exc
    for item in entries:
        try:
            st = item.stat()
            rows.append({
                "name": item.name,
                "type": "directory" if item.is_dir() else "file",
                "size_bytes": st.st_size,
                "readable": os.access(item, os.R_OK)
            })
        except OSError as exc:
            errors.append({"name": item.name, "error": str(exc)})
    return {"folder": str(p), "items": rows, "count": len(rows),
            "errors": errors, "note": "Only lists direct children; it does not modify files."}


def analyze_file(path):
    import hashlib, mimetypes
    p = _resolve(path)
    if not p.is_file(): raise FileNotFoundError(str(p))
    sha=hashlib.sha256(); md5=hashlib.md5()
    with p.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            sha.update(chunk); md5.update(chunk)
    with p.open("rb") as stream: head=stream.read(16)
    signatures={b"\\x7fELF":"ELF executable",b"MZ":"Windows executable",b"PK\\x03\\x04":"ZIP container",b"\\x1f\\x8b":"GZIP archive",b"%PDF":"PDF document"}
    detected=next((v for k,v in signatures.items() if head.startswith(k)),None)
    return {"file":str(p),"size_bytes":p.stat().st_size,"sha256":sha.hexdigest(),"md5":md5.hexdigest(),
      "extension":p.suffix.lower(),"mime_guess":mimetypes.guess_type(str(p))[0],"magic_hint":detected,
      "hidden":p.name.startswith("."),"modified_original":False,
      "note":"Static metadata and hashes only; this is not antivirus or malware execution analysis."}

def find_duplicates(folder):
    from collections import defaultdict
    p=_resolve(folder)
    if not p.is_dir(): raise NotADirectoryError(str(p))
    groups=defaultdict(list); errors=[]
    for item in p.rglob("*"):
        if item.is_file():
            try:
                st=item.stat(); groups[(st.st_size, analyze_file(item)["sha256"])].append(str(item))
            except OSError as e: errors.append({"path":str(item),"error":str(e)})
    duplicates=[{"size_bytes":k[0],"sha256":k[1],"files":v} for k,v in groups.items() if len(v)>1]
    return {"folder":str(p),"duplicate_groups":duplicates,"errors":errors,"note":"Read-only recursive hash comparison."}
