import socket
def analyze(domain):
    domain=domain.strip().lower().rstrip(".")
    if not domain or any(c.isspace() for c in domain) or "/" in domain: raise ValueError("Invalid domain.")
    result={"domain":domain,"records":{},"addresses":[],"method":"system resolver + dnspython when installed"}
    try: result["addresses"]=sorted({x[4][0] for x in socket.getaddrinfo(domain,None)})
    except Exception as e: result["address_error"]=str(e)
    try:
        import dns.resolver
        resolver=dns.resolver.Resolver(); resolver.lifetime=5
        for typ in ("A","AAAA","CNAME","MX","NS","TXT","CAA","SOA"):
            try: result["records"][typ]=[x.to_text() for x in resolver.resolve(domain,typ)]
            except Exception as e: result["records"][typ]=[]
        for label,q in (("DMARC","_dmarc."+domain),):
            try: result["records"][label]=[x.to_text() for x in resolver.resolve(q,"TXT")]
            except Exception: result["records"][label]=[]
        txt=result["records"].get("TXT",[])
        spf=[x for x in txt if "v=spf1" in x.lower()]
        result["email_security"]={"spf":spf,"dmarc":result["records"].get("DMARC",[]),
          "spf_count":len(spf),"spf_warning":"Multiple SPF records detected" if len(spf)>1 else None}
        try:
            import dns.dnssec, dns.name
            result["dnssec"]={"ds_records": [x.to_text() for x in resolver.resolve(domain,"DS")]}
        except Exception: result["dnssec"]={"status":"DS not found or validation unavailable; not a definitive DNSSEC validation"}
    except ImportError:
        result["dns_python_package"]="Install dnspython for full record inspection."
    return result
