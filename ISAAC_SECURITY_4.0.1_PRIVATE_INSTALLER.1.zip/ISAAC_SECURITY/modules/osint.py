import socket

def public_dns_recon(domain):
    domain = domain.strip().lower().rstrip(".")
    try:
        addresses = sorted({x[4][0] for x in socket.getaddrinfo(domain, None)})
    except Exception as e:
        addresses = []
        error = str(e)
    else:
        error = None
    return {"domain": domain, "resolved_addresses": addresses, "error": error,
            "note": "Public DNS resolution only; no account or private-data collection."}
