def inspect_domain(domain):
    """Read public SPF, DMARC and MX DNS records; no mailbox access."""
    domain = domain.strip().lower().rstrip(".")
    if not domain or any(ch.isspace() for ch in domain) or "/" in domain:
        raise ValueError("Enter a valid domain name.")

    result = {"domain": domain, "checks": {}, "method": "dnspython" }
    try:
        import dns.resolver
    except ImportError:
        import socket
        result["method"] = "basic system resolver"
        try:
            result["checks"]["A"] = sorted({row[4][0] for row in socket.getaddrinfo(domain, None)})
        except OSError as exc:
            result["checks"]["A_error"] = str(exc)
        result["checks"]["SPF"] = "Not checked: install dnspython for TXT record inspection."
        result["checks"]["DMARC"] = "Not checked: install dnspython for TXT record inspection."
        result["checks"]["MX"] = "Not checked: install dnspython for MX record inspection."
        result["note"] = "No email account is accessed. Install requirements for authoritative DNS record queries."
        return result

    resolver = dns.resolver.Resolver()
    resolver.lifetime = 5
    for label, qname, rtype in (
        ("SPF", domain, "TXT"),
        ("DMARC", "_dmarc." + domain, "TXT"),
        ("MX", domain, "MX"),
    ):
        try:
            answers = resolver.resolve(qname, rtype)
            values = []
            for answer in answers:
                if rtype == "TXT":
                    chunks = getattr(answer, "strings", None)
                    values.append(b"".join(chunks).decode("utf-8", "replace") if chunks else answer.to_text().strip('"'))
                else:
                    values.append(answer.to_text())
            if label == "SPF":
                values = [v for v in values if v.lower().startswith("v=spf1")]
            result["checks"][label] = values
        except Exception as exc:
            result["checks"][label] = []
            result["checks"][label + "_status"] = "not found or DNS lookup failed"
            result.setdefault("lookup_details", {})[label] = str(exc)
    result["note"] = "DNS record inspection only; no mailbox access or message sending."
    return result
