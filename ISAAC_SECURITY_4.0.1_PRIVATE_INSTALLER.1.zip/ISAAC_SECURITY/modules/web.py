"""Low-impact HTTP security inspection for explicitly authorized targets."""
import urllib.request, urllib.error, urllib.parse, re, time
from core.scoring import assess_headers
SECURITY_HEADERS=["strict-transport-security","content-security-policy","x-content-type-options","x-frame-options","referrer-policy","permissions-policy"]
def _fetch(url,timeout=10,limit=600000):
    req=urllib.request.Request(url,headers={"User-Agent":"ISAAC-SECURITY/4.0 (+defensive-audit)"})
    try: r=urllib.request.urlopen(req,timeout=timeout)
    except urllib.error.HTTPError as e: r=e
    with r:
        body=r.read(limit)
        return r.status,r.geturl(),{k.lower():v for k,v in r.headers.items()},body
def scan(url,timeout=10):
    url=url.strip()
    if not url.startswith(("http://","https://")): url="https://"+url
    parsed=urllib.parse.urlparse(url)
    if parsed.scheme not in ("http","https") or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Enter a valid HTTP(S) hostname; credentials in URLs are not accepted.")
    start=time.monotonic()
    status,final,headers,body=_fetch(url,timeout)
    https=urllib.parse.urlparse(final).scheme=="https"
    values={h:headers.get(h) for h in SECURITY_HEADERS}
    result={"final_url":final,"status":status,"https":https,"server_header":headers.get("server"),
      "security_headers":values,"missing_security_headers":[h for h,v in values.items() if not v],
      "cookies":[{"set_cookie":v[:500],"secure":"; secure" in v.lower(),"httponly":"; httponly" in v.lower(),"samesite":"samesite=" in v.lower()} for k,v in headers.items() if k=="set-cookie"],
      "cors":{"access_control_allow_origin":headers.get("access-control-allow-origin"),"access_control_allow_credentials":headers.get("access-control-allow-credentials")},
      "redirected":final.rstrip("/")!=url.rstrip("/"),"duration_seconds":round(time.monotonic()-start,3),
      "note":"Header absence is a review signal, not proof of exploitability."}
    result["assessment"]=assess_headers(result)
    # Safe, fixed public metadata files only; no crawling or arbitrary path discovery.
    extras={}
    origin=f"{urllib.parse.urlparse(final).scheme}://{urllib.parse.urlparse(final).netloc}"
    for name in ("robots.txt","sitemap.xml",".well-known/security.txt"):
        try:
            st,fu,hh,bb=_fetch(origin+"/"+name,timeout,120000)
            extras[name]={"status":st,"found":st==200,"bytes":len(bb),"url":fu}
        except Exception as e: extras[name]={"error":str(e)[:180]}
    result["public_metadata_files"]=extras
    return result
