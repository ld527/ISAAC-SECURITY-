import socket, time

COMMON_PORTS = [21, 22, 25, 53, 80, 110, 143, 443, 445, 3306, 5432, 8080, 8443]

def check_ports(host, ports=None, timeout=0.7):
    ports = ports or COMMON_PORTS
    out = []
    for port in ports:
        s = socket.socket()
        s.settimeout(timeout)
        try:
            code = s.connect_ex((host, int(port)))
            out.append({"port": int(port), "state": "open" if code == 0 else "closed_or_filtered"})
        except Exception as e:
            out.append({"port": int(port), "state": "error", "detail": str(e)})
        finally:
            s.close()
    return {"host": host, "results": out, "scope": "small common-port connectivity check"}
