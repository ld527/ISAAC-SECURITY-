#!/usr/bin/env python3
# ISAAC SUCIRITY - bilingual defensive security toolkit
from core.app import run

if __name__ == "__main__":
    run()
