# ISAAC SECURITY 4.0.0

Defensive terminal toolkit for Termux and Linux. Use only on systems you own or are explicitly authorized to assess.

## Run
```bash
python -m pip install -r requirements.txt
python main.py
```

## 4.0.0
- Evidence-based HTTP header scoring and remediation guidance.
- Cookie/CORS indicators and public robots.txt, sitemap.xml and security.txt checks.
- Heuristic technology fingerprinting with confidence indicators.
- Expanded DNS record inspection.
- TLS certificate expiry warning.
- Read-only file hashing/type hints and duplicate detection.
- JSON, HTML, TXT and CSV reports, history dashboard, settings and logging.
- Automated core tests.

Scores and fingerprints are indicators, not proof of security or vulnerability. File inspection is not antivirus. No exploit attempts or private-data collection are performed.
