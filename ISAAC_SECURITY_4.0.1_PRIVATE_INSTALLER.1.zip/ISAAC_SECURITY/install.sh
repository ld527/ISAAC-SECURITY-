#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="${ISAAC_HOME:-$HOME/.local/share/isaac-security}"
BIN_DIR="${ISAAC_BIN:-$HOME/.local/bin}"

if ! command -v python >/dev/null 2>&1; then
  echo "[!] Python غير مثبت. ثبّته أولاً: pkg install python (Termux) أو مدير حزم نظامك."
  exit 1
fi
if ! command -v git >/dev/null 2>&1; then
  echo "[!] Git غير مثبت. ثبّته أولاً: pkg install git"
  exit 1
fi

mkdir -p "$INSTALL_DIR" "$BIN_DIR"
# انسخ ملفات المشروع مع الحفاظ على .git إن كان المصدر مستنسخاً من مستودع خاص.
( cd "$SOURCE_DIR" && tar --exclude='./__pycache__' --exclude='*.pyc' -cf - . ) | ( cd "$INSTALL_DIR" && tar -xf - )

python -m pip install -r "$INSTALL_DIR/requirements.txt"

cat > "$BIN_DIR/isaac" <<LAUNCHER
#!/usr/bin/env bash
exec python "$INSTALL_DIR/main.py" "\$@"
LAUNCHER
chmod +x "$BIN_DIR/isaac"

# اجعل أمر isaac متاحاً في الجلسات التالية.
PROFILE="$HOME/.bashrc"
[ -n "${PREFIX:-}" ] && PROFILE="$HOME/.bashrc"
if ! grep -Fq 'export PATH="$HOME/.local/bin:$PATH"' "$PROFILE" 2>/dev/null; then
  printf '\n# ISAAC SECURITY command\nexport PATH="$HOME/.local/bin:$PATH"\n' >> "$PROFILE"
fi

# التحديث التلقائي يتطلب تثبيت المصدر من clone لمستودع Git خاص.
if [ -d "$SOURCE_DIR/.git" ]; then
  echo "[+] تم الاحتفاظ ببيانات Git للمستودع الخاص."
else
  echo "[i] هذه نسخة ZIP محلية؛ التحديث التلقائي يتطلب إعادة التثبيت من clone للمستودع الخاص."
fi

cat > "$BIN_DIR/isaac-update" <<UPDATER
#!/usr/bin/env bash
set -euo pipefail
APP="$INSTALL_DIR"
if [ ! -d "\$APP/.git" ]; then
  echo '[!] لا يوجد مستودع Git مضبوط. أعد التثبيت من clone للمستودع الخاص أو اضبط remote origin.'
  exit 1
fi
git -C "\$APP" pull --ff-only
python -m pip install -r "\$APP/requirements.txt"
echo '[+] ISAAC SECURITY updated.'
UPDATER
chmod +x "$BIN_DIR/isaac-update"

cat > "$BIN_DIR/isaac-uninstall" <<UNINSTALLER
#!/usr/bin/env bash
set -euo pipefail
rm -rf "$INSTALL_DIR"
rm -f "$BIN_DIR/isaac" "$BIN_DIR/isaac-update" "$BIN_DIR/isaac-uninstall"
echo 'ISAAC SECURITY application files removed. Reports or backups outside the install directory are not touched.'
UNINSTALLER
chmod +x "$BIN_DIR/isaac-uninstall"

echo
echo '[+] Installation complete.'
echo 'Run: isaac'
echo 'Update: isaac-update'
echo 'Uninstall: isaac-uninstall'
echo 'If command is not found, run: source ~/.bashrc'
