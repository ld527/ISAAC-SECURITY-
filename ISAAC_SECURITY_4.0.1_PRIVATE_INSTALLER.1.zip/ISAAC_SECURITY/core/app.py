import getpass
import json
import re
from pathlib import Path

from core.ui import *
from core.engine import Engine
from modules import (
    web, dns, tls, network, technology, email_security, files, device,
    privacy, osint, vulnerabilities, accounts
)

TEXT = {
    "en": {
        "menu": ["WEB SECURITY", "ACCOUNT SECURITY", "NETWORK SECURITY",
                 "DEVICE SECURITY", "FILE SECURITY", "OSINT INTELLIGENCE",
                 "VULNERABILITY INTELLIGENCE", "PRIVACY & TRACKING",
                 "EMAIL SECURITY", "PASSWORD SECURITY", "REPORT CENTER",
                 "SYSTEM INFORMATION", "SETTINGS", "DASHBOARD", "EXIT"],
        "choose": "Select: ", "saved": "Report saved: ", "target": "Authorized target domain/host: ",
        "password": "Password for local strength check (not transmitted): ",
        "reports": "SAVED REPORTS", "empty": "No reports yet.", "back": "BACK",
        "settings": "SETTINGS", "language": "Choose language", "invalid": "Invalid input.",
        "folder": "Folder path: ", "file": "File path: ", "port": "Port (default 443): ",
        "exit": "ISAAC SUCIRITY CLOSED.", "scope": "Only scan systems you own or are explicitly authorized to test.",
        "report_error": "Could not read report: ", "cancelled": "Cancelled."
    },
    "ar": {
        "menu": ["أمن الويب", "أمن الحسابات", "أمن الشبكات",
                 "أمن الأجهزة", "أمن الملفات", "استخبارات المصادر المفتوحة",
                 "معلومات الثغرات", "الخصوصية والتتبع",
                 "أمن البريد الإلكتروني", "أمن كلمات المرور", "مركز التقارير",
                 "معلومات النظام", "الإعدادات", "لوحة المعلومات", "خروج"],
        "choose": "اختر: ", "saved": "تم حفظ التقرير: ", "target": "النطاق/المضيف المصرح لك بفحصه: ",
        "password": "كلمة المرور للتقييم المحلي (لن تُرسل): ",
        "reports": "التقارير المحفوظة", "empty": "لا توجد تقارير بعد.", "back": "رجوع",
        "settings": "الإعدادات", "language": "اختر اللغة", "invalid": "إدخال غير صحيح.",
        "folder": "مسار المجلد: ", "file": "مسار الملف: ", "port": "المنفذ (الافتراضي 443): ",
        "exit": "تم إغلاق ISAAC SUCIRITY.", "scope": "افحص فقط الأنظمة التي تملكها أو لديك تصريح صريح لاختبارها.",
        "report_error": "تعذر قراءة التقرير: ", "cancelled": "تم الإلغاء."
    }
}

def show_data(data):
    print()
    print(paint(CYAN, json.dumps(data, indent=2, ensure_ascii=False, default=str)))

def valid_host(value):
    value = value.strip()
    if not value or len(value) > 253 or any(c.isspace() for c in value):
        raise ValueError("Enter a valid hostname or IP address.")
    if "://" in value:
        from urllib.parse import urlparse
        parsed = urlparse(value)
        value = parsed.hostname or ""
    value = value.rstrip(".")
    if not value or not re.fullmatch(r"[A-Za-z0-9.-]+", value):
        raise ValueError("Invalid hostname. Enter a domain or IP without a path.")
    if value.startswith(".") or value.endswith(".") or ".." in value:
        raise ValueError("Invalid hostname format.")
    return value

def run_tool(engine, name, target, fn):
    try:
        loading(name, engine.lang)
        data = fn()
        show_data(data)
        path = engine.save(name, target, data)
        print(paint(GREEN, TEXT[engine.lang]["saved"] + str(path)))
    except KeyboardInterrupt:
        print(paint(YELLOW, TEXT[engine.lang]["cancelled"]))
    except Exception as exc:
        print(paint(RED, "Error: " + str(exc)))
    pause(engine.lang)

def reports_menu(lang):
    report_dir = Path(__file__).resolve().parents[1] / "reports"
    items = sorted(report_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not items:
        print(TEXT[lang]["empty"])
        pause(lang)
        return
    idx = select_menu([p.name for p in items[:100]], lang, TEXT[lang]["reports"])
    if idx == "QUIT" or idx is None:
        return
    try:
        show_data(json.loads(items[idx].read_text(encoding="utf-8")))
    except Exception as exc:
        print(paint(RED, TEXT[lang]["report_error"] + str(exc)))
    pause(lang)

def choose(items, lang, title):
    labels = list(items) + [TEXT[lang]["back"]]
    idx = select_menu(labels, lang, title)
    if idx in (None, "QUIT") or idx >= len(items):
        return None
    return idx

def ask_target(t):
    return valid_host(ask(t["target"]))

def category(engine, n):
    lang = engine.lang
    t = TEXT[lang]
    if n == 1:
        x = choose(["HTTP security headers" if lang == "en" else "ترويسات أمان HTTP",
                    "Technology fingerprint" if lang == "en" else "التعرف على تقنيات الموقع"],
                   lang, t["menu"][0])
        if x == 0:
            h = ask_target(t); run_tool(engine, "web_headers", h, lambda: web.scan(h))
        elif x == 1:
            h = ask_target(t); run_tool(engine, "technology", h, lambda: technology.detect(h))
    elif n == 2:
        if choose(["Account hardening checklist" if lang == "en" else "قائمة تقوية الحسابات"],
                  lang, t["menu"][1]) == 0:
            run_tool(engine, "account_hardening", "local_checklist", accounts.account_hardening)
    elif n == 3:
        labels = (["DNS analysis", "Common port connectivity check", "TLS certificate inspection"]
                  if lang == "en" else ["تحليل DNS", "فحص اتصال المنافذ الشائعة", "فحص شهادة TLS"])
        x = choose(labels, lang, t["menu"][2])
        if x == 0:
            h = ask_target(t); run_tool(engine, "dns", h, lambda: dns.analyze(h))
        elif x == 1:
            h = ask_target(t)
            print(paint(YELLOW, t["scope"]))
            run_tool(engine, "ports", h, lambda: network.check_ports(h))
        elif x == 2:
            h = ask_target(t)
            p = ask(t["port"]) or "443"
            if not p.isdigit() or not 1 <= int(p) <= 65535:
                print(paint(RED, t["invalid"])); pause(lang); return
            run_tool(engine, "tls", f"{h}:{p}", lambda: tls.inspect(h, int(p)))
    elif n == 4:
        run_tool(engine, "device_info", "local_device", device.info)
    elif n == 5:
        x = choose(["Folder inventory", "File hash + type analysis", "Find duplicate files"] if lang == "en"
                   else ["جرد مجلد", "تحليل الملف والبصمات", "البحث عن الملفات المكررة"], lang, t["menu"][4])
        if x == 0:
            p = ask(t["folder"])
            run_tool(engine, "file_inventory", p, lambda: files.inventory(p))
        elif x == 1:
            p = ask(t["file"])
            run_tool(engine, "file_analysis", p, lambda: files.analyze_file(p))
        elif x == 2:
            p = ask(t["folder"])
            run_tool(engine, "file_duplicates", p, lambda: files.find_duplicates(p))
    elif n == 6:
        h = ask_target(t)
        run_tool(engine, "public_dns_osint", h, lambda: osint.public_dns_recon(h))
    elif n == 7:
        run_tool(engine, "hardening_baseline", "security_checklist", vulnerabilities.explain_baseline)
    elif n == 8:
        run_tool(engine, "privacy_snapshot", "local_device", privacy.local_privacy_snapshot)
    elif n == 9:
        h = ask_target(t)
        run_tool(engine, "email_domain_security", h, lambda: email_security.inspect_domain(h))
    elif n == 10:
        try:
            p = getpass.getpass(t["password"])
            data = engine.password_audit(p)
            show_data(data)
            path = engine.save("password_strength", "local_password", data)
            print(paint(GREEN, t["saved"] + str(path)))
        except (KeyboardInterrupt, EOFError):
            print(paint(YELLOW, t["cancelled"]))
        pause(lang)
    elif n == 11:
        reports_menu(lang)
    elif n == 12:
        show_data(engine.system_info())
        pause(lang)
    elif n == 13:
        x = choose(["English", "العربية", "Toggle terminal colors"] if lang == "en" else ["English", "العربية", "تبديل ألوان الطرفية"], lang, t["language"])
        if x == 2:
            engine.settings["colors"] = not engine.settings.get("colors", True)
            from core.config_manager import save
            save(engine.settings)
            print("Colors:", engine.settings["colors"]); pause(lang)
        elif x == 0:
            engine.set_language("en")
            LANG[0] = "en"
        elif x == 1:
            engine.set_language("ar")
            LANG[0] = "ar"

def run():
    engine = Engine()
    LANG[0] = engine.lang
    while True:
        lang = engine.lang
        header(lang)
        title = "MAIN MENU" if lang == "en" else "القائمة الرئيسية"
        idx = select_menu(TEXT[lang]["menu"], lang, title)
        if idx == "QUIT" or idx == 14:
            clear()
            print(paint(GREEN, TEXT[lang]["exit"]))
            break
        if idx is None:
            continue
        if idx == 13:
            from core.history import recent
            rows = recent(20)
            summary = {"recent_scans": len(rows), "reports_saved": len(list((Path(__file__).resolve().parents[1] / "reports").glob("*.json"))),
                       "latest": [{"tool":r.get("tool"),"target":r.get("target"),"date":r.get("date")} for r in rows[:10]],
                       "version": engine.settings.get("version")}
            show_data(summary); pause(lang)
        else:
            category(engine, idx + 1)
