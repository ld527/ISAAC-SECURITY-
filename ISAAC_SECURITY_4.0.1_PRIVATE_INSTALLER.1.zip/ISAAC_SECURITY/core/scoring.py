"""Evidence-based security scoring. Unchecked controls are excluded."""
WEIGHTS = {
 "strict-transport-security": (15, "HIGH", "Enforce HTTPS with a suitable max-age; consider includeSubDomains only when all subdomains support HTTPS."),
 "content-security-policy": (20, "HIGH", "Deploy a restrictive Content-Security-Policy; start with Report-Only and tune it."),
 "x-content-type-options": (10, "MEDIUM", "Set X-Content-Type-Options: nosniff."),
 "x-frame-options": (10, "MEDIUM", "Set X-Frame-Options: DENY or SAMEORIGIN, or use CSP frame-ancestors."),
 "referrer-policy": (10, "LOW", "Set Referrer-Policy: strict-origin-when-cross-origin or a stricter policy."),
 "permissions-policy": (10, "LOW", "Explicitly disable browser features the site does not use."),
}
def assess_headers(data):
    headers=data.get("security_headers",{})
    findings=[]; possible=0; earned=0
    for name,(weight,severity,fix) in WEIGHTS.items():
        value=headers.get(name)
        if value is None:
            findings.append({"id":"missing-"+name,"severity":severity,"title":"Missing "+name,
             "evidence":"Header absent from inspected response","recommendation":fix,"weight":weight})
        else:
            earned += weight
            findings.append({"id":"present-"+name,"severity":"INFO","title":name+" present",
             "evidence":str(value)[:300],"recommendation":"Review value for application-specific suitability.","weight":0})
        possible += weight
    score=round(100*earned/possible) if possible else None
    return {"score":score,"score_basis":"observed headers only; not a full vulnerability assessment",
      "grade":("Excellent" if score>=90 else "Good" if score>=75 else "Moderate" if score>=50 else "Weak" if score>=25 else "Critical") if score is not None else "Not assessed",
      "findings":findings,"checked_controls":len(WEIGHTS)}
