import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PATH=ROOT/"config"/"settings.json"
DEFAULTS={"language":"en","version":"4.0.0","theme":"cyber-terminal","colors":True,"timeout":10,"max_requests":5,"detail":"standard","report_formats":["json","html","txt","csv"],"enabled_modules":{}}
def load():
    data=dict(DEFAULTS)
    try:
        user=json.loads(PATH.read_text(encoding="utf-8"))
        if isinstance(user,dict): data.update(user)
    except (OSError,ValueError): pass
    return data
def save(data):
    PATH.parent.mkdir(exist_ok=True)
    PATH.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
