import os
import sys
import time

R = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[38;5;203m"
GREEN = "\033[38;5;82m"
YELLOW = "\033[38;5;220m"
BLUE = "\033[38;5;75m"
MAGENTA = "\033[38;5;141m"
CYAN = "\033[38;5;51m"
WHITE = "\033[38;5;255m"
PANEL = "\033[38;5;39m"

LANG = ["en"]
USE_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None

def paint(color, value):
    return f"{color}{value}{R}" if USE_COLOR else str(value)

def _width():
    try:
        return max(32, min(72, os.get_terminal_size().columns))
    except OSError:
        return 48

def clear():
    if sys.stdout.isatty():
        os.system("clear")
    else:
        print("\n" * 2)

def bar(char="━"):
    print(paint(PANEL, char * min(_width(), 60)))

def header(lang):
    clear()
    w = min(_width(), 60)
    print(paint(CYAN + BOLD, "╔" + "═" * (w-2) + "╗"))
    title = "ISAAC // SECURITY" if lang == "en" else "ISAAC // الأمن السيبراني"
    subtitle = "DEFENSIVE SECURITY OPERATIONS  •  v4.0.0"
    print(paint(CYAN + BOLD, "║" + title.center(w-2) + "║"))
    print(paint(DIM, "║" + subtitle.center(w-2)[:w-2] + "║"))
    print(paint(CYAN + BOLD, "╚" + "═" * (w-2) + "╝"))
    print(paint(GREEN, "  ● SYSTEM READY") + paint(DIM, "   |   LOCAL TERMINAL CONSOLE"))
    bar()

def _read_key():
    import select
    import termios
    import tty
    fd = sys.stdin.fileno()
    if not os.isatty(fd):
        value = input("Select: ").strip()
        return value or "ENTER"
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        first = os.read(fd, 1)
        if not first: return "ESC"
        if first == b"\x03": return "Q"
        if first == b"\x1b":
            seq = bytearray(first)
            deadline = time.monotonic() + 0.45
            while len(seq) < 8:
                remain = deadline - time.monotonic()
                if remain <= 0 or not select.select([fd], [], [], remain)[0]: break
                seq.extend(os.read(fd, 1))
                if seq in (b"\x1b[A", b"\x1b[B", b"\x1b[C", b"\x1b[D",
                           b"\x1bOA", b"\x1bOB", b"\x1bOC", b"\x1bOD"): break
            return {b"\x1b[A":"UP", b"\x1b[B":"DOWN", b"\x1b[C":"RIGHT",
                    b"\x1b[D":"LEFT", b"\x1bOA":"UP", b"\x1bOB":"DOWN",
                    b"\x1bOC":"RIGHT", b"\x1bOD":"LEFT"}.get(bytes(seq), "ESC")
        if first in (b"\r", b"\n"): return "ENTER"
        if first in (b"\x7f", b"\x08"): return "BACKSPACE"
        char = first.decode("utf-8", errors="ignore")
        return "Q" if char in ("q", "Q") else char
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)

def select_menu(items, lang="en", title=None, back=True):
    if not items: return None
    selected = 0
    while True:
        clear()
        if title:
            print(paint(CYAN + BOLD, "▌ " + title.upper()))
            bar()
        for i, item in enumerate(items):
            mark = "◆" if i == selected else "◇"
            color = GREEN + BOLD if i == selected else WHITE
            print(paint(color, f" {mark}  {i+1:02d}  {item}"))
        bar()
        hint = ("↑/↓ Navigate   ENTER Open   ← Back   Q Exit" if lang == "en"
                else "↑/↓ تنقل   ENTER اختيار   ← رجوع   Q خروج")
        print(paint(YELLOW, hint))
        key = _read_key()
        if key == "UP": selected = (selected - 1) % len(items)
        elif key == "DOWN": selected = (selected + 1) % len(items)
        elif key in ("ENTER", "RIGHT"): return selected
        elif key in ("LEFT", "ESC", "BACKSPACE"): return None
        elif key == "Q": return "QUIT"
        elif isinstance(key, str) and key.isdigit():
            n = int(key)
            if 1 <= n <= len(items): return n - 1

def loading(label, lang):
    msg = ("جارٍ التنفيذ: " if lang == "ar" else "EXECUTING: ") + label
    print(paint(CYAN + BOLD, "\n[>>] " + msg))
    for _ in range(20):
        print(paint(GREEN, "▰"), end="", flush=True)
        time.sleep(0.012)
    print(paint(GREEN, "  DONE"))

def pause(lang):
    try: input(paint(DIM, "\nاضغط Enter للمتابعة..." if lang == "ar" else "\nPress Enter to continue..."))
    except (EOFError, KeyboardInterrupt): pass

def ask(prompt):
    try: return input(paint(CYAN, prompt)).strip()
    except (EOFError, KeyboardInterrupt): return ""

def status(ok, ar, en):
    print(paint(GREEN if ok else YELLOW, ("[+] " if ok else "[!] ") +
                (ar if LANG[0] == "ar" else en)))
