import logging
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def get_logger():
    logger=logging.getLogger("isaac_security")
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        h=logging.FileHandler(ROOT/"logs"/"isaac.log",encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(h)
    return logger
