import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
HISTORY=ROOT/"history"
def record(payload):
    HISTORY.mkdir(exist_ok=True)
    p=HISTORY/(payload.get("tool","scan").replace("/","_")+"_"+payload.get("date","").replace(":","-")+".json")
    p.write_text(json.dumps(payload,ensure_ascii=False,indent=2,default=str),encoding="utf-8")
    return p
def recent(limit=30):
    HISTORY.mkdir(exist_ok=True)
    out=[]
    for p in sorted(HISTORY.glob("*.json"),key=lambda x:x.stat().st_mtime,reverse=True)[:limit]:
        try: out.append(json.loads(p.read_text(encoding="utf-8")))
        except Exception: continue
    return out
