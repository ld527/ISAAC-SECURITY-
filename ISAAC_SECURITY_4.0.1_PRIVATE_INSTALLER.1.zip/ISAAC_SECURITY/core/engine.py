import json
import platform
import socket
import hashlib
import datetime
from pathlib import Path
import time
from core.reporting import export_all
from core.history import record
from core.logger import get_logger
from core.config_manager import load as load_config

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"
CONFIG = ROOT / "config" / "settings.json"
REPORTS.mkdir(exist_ok=True)
CONFIG.parent.mkdir(exist_ok=True)

class Engine:
    def __init__(self, lang=None):
        self.settings = self._load_settings()
        self.lang = lang or self.settings.get("language", "en")
        if self.lang not in ("en", "ar"):
            self.lang = "en"

    def _load_settings(self):
        defaults = load_config()
        try:
            data = json.loads(CONFIG.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                defaults.update(data)
        except (OSError, ValueError):
            pass
        return defaults

    def set_language(self, lang):
        if lang not in ("en", "ar"):
            raise ValueError("Unsupported language")
        self.lang = lang
        self.settings["language"] = lang
        CONFIG.write_text(json.dumps(self.settings, indent=2, ensure_ascii=False), encoding="utf-8")

    def save(self, module, target, data):
        stamp = datetime.datetime.now().astimezone()
        safe_module = "".join(c if c.isalnum() or c in "-_." else "_" for c in str(module))[:40]
        safe_target = "".join(c if c.isalnum() or c in "-_." else "_" for c in str(target))[:70] or "local"
        path = REPORTS / f"{safe_module}_{safe_target}_{stamp.strftime('%Y%m%d_%H%M%S_%f')}.json"
        payload = {"tool": module, "target": target, "date": stamp.isoformat(),
                   "duration_seconds": data.get("duration_seconds") if isinstance(data, dict) else None,
                   "version": self.settings.get("version", "4.0.0"), "data": data}
        exports = export_all(payload, path.with_suffix(""))
        record(payload)
        get_logger().info("saved %s for %s", module, target)
        return Path(exports["json"])

    def system_info(self):
        return {
            "project": "ISAAC SECURITY", "version": self.settings.get("version", "3.3"),
            "platform": platform.platform(), "python": platform.python_version(),
            "hostname": socket.gethostname(), "architecture": platform.machine(),
            "reports": len(list(REPORTS.glob("*.json"))),
            "language": self.lang, "optional_dns_library": self._has_dns(), "history_entries": len(list((ROOT / "history").glob("*.json")))
        }

    @staticmethod
    def _has_dns():
        try:
            import dns.resolver  # noqa: F401
            return True
        except ImportError:
            return False

    def password_audit(self, password):
        checks = {
            "length_12_plus": len(password) >= 12,
            "lowercase": any(c.islower() for c in password),
            "uppercase": any(c.isupper() for c in password),
            "digits": any(c.isdigit() for c in password),
            "symbols": any(not c.isalnum() for c in password),
            "not_common_pattern": password.lower() not in {
                "password", "123456789", "qwerty123", "admin123", "letmein"
            }
        }
        score = sum(checks.values())
        level = "strong" if score >= 5 and len(password) >= 12 else "moderate" if score >= 3 else "weak"
        return {"length": len(password), "score": score, "out_of": len(checks),
                "rating": level, "checks": checks,
                "note": "Evaluated locally. The password itself is never saved or transmitted."}

    def file_hash(self, path):
        p = Path(path).expanduser()
        if not p.is_file():
            raise FileNotFoundError(f"File not found: {p}")
        h = hashlib.sha256()
        with p.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return {"file": str(p.resolve()), "size_bytes": p.stat().st_size, "sha256": h.hexdigest()}
