import csv, html, json
from pathlib import Path
def export_all(payload, base):
    base=Path(base); base.parent.mkdir(parents=True,exist_ok=True)
    json_path=base.with_suffix(".json")
    json_path.write_text(json.dumps(payload,ensure_ascii=False,indent=2,default=str),encoding="utf-8")
    flat=[]
    def walk(prefix,obj):
        if isinstance(obj,dict):
            for k,v in obj.items(): walk(prefix+"."+str(k) if prefix else str(k),v)
        elif isinstance(obj,list):
            for i,v in enumerate(obj): walk(f"{prefix}[{i}]",v)
        else: flat.append((prefix,str(obj)))
    walk("",payload)
    txt=base.with_suffix(".txt")
    txt.write_text("\n".join(f"{k}: {v}" for k,v in flat),encoding="utf-8")
    csvp=base.with_suffix(".csv")
    with csvp.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f); w.writerow(["field","value"]); w.writerows(flat)
    score=payload.get("data",{}).get("assessment",{}).get("score")
    rows="".join(f"<tr><th>{html.escape(k)}</th><td>{html.escape(v)}</td></tr>" for k,v in flat)
    page=f"""<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ISAAC SECURITY Report</title><style>body{{background:#080d14;color:#d8faff;font:15px system-ui;margin:2rem}}h1{{color:#32e6ef}}.score{{font-size:2rem;color:#7dff74}}table{{border-collapse:collapse;width:100%;overflow-wrap:anywhere}}td,th{{border:1px solid #24505a;padding:8px;text-align:left}}th{{color:#7dff74}}tr:nth-child(even){{background:#101b25}}</style><h1>ISAAC // SECURITY</h1><p>Defensive assessment report</p><div class="score">Score: {html.escape(str(score if score is not None else 'N/A'))}/100</div><table>{rows}</table></html>"""
    hp=base.with_suffix(".html"); hp.write_text(page,encoding="utf-8")
    return {"json":str(json_path),"html":str(hp),"txt":str(txt),"csv":str(csvp)}
